package com.react.exem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemApplicationTests {

	@Test
	void contextLoads() {
	}

}
