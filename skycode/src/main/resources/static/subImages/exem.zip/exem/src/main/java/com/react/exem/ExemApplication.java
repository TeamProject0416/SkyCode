package com.react.exem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemApplication.class, args);
	}

}
