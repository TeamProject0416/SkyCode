package teamproject.skycode.constant;

public enum Gender {
    MALE, FEMALE
}
