package teamproject.skycode.constant;

public enum TicketCountry {
    Korea, Japan, Mexico, USA, NewYork, Paris, Switzerland, Egypt,
    Maldive, Bangkok, Hanoi, HongKong, Macau, Beijing, Australia ,Guam

    // 여행 지역
}
