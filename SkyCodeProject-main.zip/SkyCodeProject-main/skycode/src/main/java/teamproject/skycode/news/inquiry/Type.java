package teamproject.skycode.news.inquiry;

public enum Type {
    AIRPLANE, PACKAGE, PAYMENT, MEMBERSHIP
}
