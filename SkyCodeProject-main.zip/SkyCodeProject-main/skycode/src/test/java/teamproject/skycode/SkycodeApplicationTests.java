package teamproject.skycode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkycodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
